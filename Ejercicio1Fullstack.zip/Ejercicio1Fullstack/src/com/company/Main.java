package com.company;

import javax.swing.text.html.Option;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {

  public static void main(String[] args) {

    File archivo = null;
    FileReader fr = null;

    List<Persona> listaPersonas = new ArrayList<Persona>();

    String[] corte;
    String nombre = null;
    String ciudad = null;
    Integer edad = 0;

    Optional<String> opNombre = Optional.empty();
    Optional<String> opCiudad = Optional.empty();
    Optional<Integer> opEdad = Optional.empty();

    try {
      archivo = new File("C:\\personas.txt");
      fr = new FileReader(archivo);
      BufferedReader br = new BufferedReader(fr);
      String linea;

      while ((linea = br.readLine()) != null) {
        corte = linea.split(":");

        opNombre = Optional.of(corte[0]);
        opCiudad = Optional.of(Optional.of(corte[1]).orElse("Desconocido"));
        try {

          opEdad = Optional.of(Integer.valueOf(corte[2]));
        } catch (IndexOutOfBoundsException e) {
          opEdad = Optional.of(Integer.valueOf((999)));
        }

        Persona p = new Persona(opNombre.get(), opCiudad.get(), opEdad.get());
        listaPersonas.add(p);
      }

    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }

    System.out.println("-----------");

    listaPersonas.stream()
        .filter((e) -> e.getEdad() < 25)
        .forEach(
            (p) -> {
              System.out.println(
                  "Nombre: "
                      + p.getNombre()
                      + ", Poblacion:"
                      + p.getPoblacion()
                      + ", Edad: "
                      + p.getEdad());
            });
  }
}
