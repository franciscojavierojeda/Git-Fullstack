package com.example.inyeccionDeDependencias;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("PersonaService")
public class PersonaService implements PersonaServiceInt {
  @Autowired List<Persona> personas;

  private Persona person;

  @Override
  public void anadirPersona(Persona persona) {
    personas.add(persona);
  }

  public Persona getPersona() {
    return person;
  }

  @Override
  public String toString() {
    return "PersonaService{" + "p=" + person + '}';
  }

  public Persona modificarPersona(String id, Persona persona) {
    for (Persona p : personas) {
      if (p.getId().equals(id)) {
        if (persona.getNombre() != null) p.setNombre(persona.getNombre());
        if (persona.getCiudad() != null) p.setCiudad(persona.getCiudad());
        if (persona.getEdad() != null) p.setEdad(persona.getEdad());

        return p;
      }
    }
    return null;
  }

  public String eliminarPersona(String id) {
    for (Persona p : personas) {
      if (p.getId().equals(id)) {
        personas.remove(p);

        return "Usuario eliminado";
      }
    }
    return "No se ha encontrado el usuario";
  }

  public List<Persona> buscarPersona(String nombre) {
    List<Persona> personaABuscar = new ArrayList<>();
    for (Persona p : personas) {
      if (p.getNombre().equals(nombre)) {
        personaABuscar.add(p);
      }
    }
    return personaABuscar;
  }
}
