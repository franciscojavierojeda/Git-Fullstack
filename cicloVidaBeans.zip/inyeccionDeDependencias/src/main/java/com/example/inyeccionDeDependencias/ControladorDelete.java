package com.example.inyeccionDeDependencias;

import com.example.inyeccionDeDependencias.Ciudad;
import com.example.inyeccionDeDependencias.Persona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ControladorDelete {

    @Autowired List<Persona> personas;
    @Autowired PersonaService personaService;

    @RequestMapping(value = "/controlador1/personaDelete{id}", method = RequestMethod.DELETE)
    public String anadirPersona(@RequestParam String id) {

        String delete=personaService.eliminarPersona(id);

        return delete;
    }
}
