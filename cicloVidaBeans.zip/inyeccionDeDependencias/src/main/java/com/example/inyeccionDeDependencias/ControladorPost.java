package com.example.inyeccionDeDependencias;


import com.example.inyeccionDeDependencias.Ciudad;
import com.example.inyeccionDeDependencias.Persona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ControladorPost {

    @Autowired
    List<Persona> personas;

    @RequestMapping(value = "/controlador1/persona", method = RequestMethod.POST)
    public Persona anadirPersona(@RequestBody Persona persona){
        personas.add(persona);
        return persona;
    }


}
