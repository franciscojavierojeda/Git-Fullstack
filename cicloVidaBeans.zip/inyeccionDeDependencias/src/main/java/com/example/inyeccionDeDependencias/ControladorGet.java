package com.example.inyeccionDeDependencias;

import com.example.inyeccionDeDependencias.Ciudad;
import com.example.inyeccionDeDependencias.Persona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.List;

@RestController
public class ControladorGet {

    @Autowired List<Persona> personas;
    @Autowired PersonaService personaService;

    @RequestMapping(value = "/controlador1/personaGet{nombre}", method = RequestMethod.GET)
    public String anadirPersona(@RequestParam String nombre) {

        List<Persona> personasABuscar=personaService.buscarPersona(nombre);

        return personasABuscar.toString();
    }

    @PostConstruct
    public void init(){
    System.out.println("Hola desde la clase principal");
    }
}
