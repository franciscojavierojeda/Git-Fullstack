package com.example.inyeccionDeDependencias;

import java.util.List;

public interface CiudadService {

    public void anadirCiudad(Ciudad ciudad);

    public List<Ciudad> getListaCiudades();


    }
