package com.example.inyeccionDeDependencias;

import com.example.inyeccionDeDependencias.Ciudad;
import com.example.inyeccionDeDependencias.CiudadService;
import com.example.inyeccionDeDependencias.Persona;
import com.example.inyeccionDeDependencias.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class Controlador1 {

  @Autowired
  PersonaService personaService;

  @Autowired
  CiudadService ciudadService;


  @GetMapping("/controlador1/addPersona")
  public String addPersona(@RequestHeader String id, @RequestHeader String nombre, @RequestHeader(required=false) String ciudad, @RequestHeader Integer edad ) {
    Persona persona=new Persona(id,nombre,ciudad,edad);
    personaService.anadirPersona(persona);

    return personaService.toString();
  }

  @PostMapping("controlador1/addCiudad")
  public Ciudad addCiudad(@RequestBody Ciudad c){
    ciudadService.anadirCiudad(c);

    return c;
  }

  @GetMapping("/controlador1")
  public String hola(){
    return "hola";
  }
}
