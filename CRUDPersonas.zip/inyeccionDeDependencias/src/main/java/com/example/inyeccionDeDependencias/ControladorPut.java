package com.example.inyeccionDeDependencias;

import com.example.inyeccionDeDependencias.Ciudad;
import com.example.inyeccionDeDependencias.Persona;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("persona")
public class ControladorPut {

  @Autowired List<Persona> personas;
  @Autowired PersonaService personaService;

  @PutMapping("/{id}")
  public Persona modificarPersona(@RequestParam String id, @RequestBody Persona persona) {

    Persona p=personaService.modificarPersona(id,persona);

    return p;
  }
}
