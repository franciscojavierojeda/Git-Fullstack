package com.example.inyeccionDeDependencias;


import java.util.List;

public interface PersonaServiceInt {

    public void anadirPersona(Persona persona);
    public Persona modificarPersona(String id,Persona persona);
    public List<Persona> buscarPersona(String nombre);

    }
