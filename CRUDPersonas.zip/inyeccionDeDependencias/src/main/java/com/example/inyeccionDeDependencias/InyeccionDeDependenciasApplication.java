package com.example.inyeccionDeDependencias;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class InyeccionDeDependenciasApplication {

  public static void main(String[] args) {
    SpringApplication.run(InyeccionDeDependenciasApplication.class, args);
  }

  @Bean
  public List<Ciudad> ciudades(){
    List<Ciudad> ciudades=new ArrayList<>();
    return ciudades;
  }
  @Bean
  @Qualifier("personas")
  List<Persona> personas(){
    List<Persona> personas = new ArrayList<>();
    return personas;
  }
}
