package com.example.ejemploJPA.infrastructure.controllers.dtos.input.profesor;

import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfesorInputDTO {

    private Integer idProfesor;
    private Integer idPersona;
    private String comments;
    private String branch;
    private List<Student> students;


    public ProfesorInputDTO(Profesor profesor){
        this.idProfesor=profesor.getIdProfesor();
        this.idPersona= profesor.getPersona().getId();
        this.comments=profesor.getComments();
        this.branch=profesor.getBranch();
        this.students=profesor.getStudents();
    }

}
