package com.example.ejemploJPA.infrastructure.repository.asignatura;

import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AsignaturaRepositorio extends JpaRepository<Asignatura,Integer> {

}
