package com.example.ejemploJPA;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@SpringBootApplication
@EnableFeignClients
public class EjemploJpaApplication {


	public static void main(String[] args) {
		SpringApplication.run(EjemploJpaApplication.class, args);
	}



}
