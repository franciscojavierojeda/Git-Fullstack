package com.example.ejemploJPA.infrastructure.controllers.controladores.persona;

import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.application.interfaces.persona.PersonaInterfaz;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.persona.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.persona.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.profesor.ProfesorOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.feign.IFeignServer;
import com.example.ejemploJPA.infrastructure.repository.persona.PersonaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/persona")
public class PersonaController {

    @Autowired
    PersonaRepositorio personaRepositorio;

    @Autowired
    PersonaInterfaz personaInterfaz;

    @Autowired
    IFeignServer iFeignServer;

    @GetMapping
    public List<Persona> getHola() {
        return personaRepositorio.findAll();
    }

    @PostMapping
    public PersonaOutputDTO anadirUsuario(@RequestBody PersonaInputDTO personaInputDTO) {
        PersonaOutputDTO personaOutputDTO = personaInterfaz.creaPersona(personaInputDTO);
        System.out.println("Usuario anadido correctamente");
        return personaOutputDTO;
    }

    @GetMapping("/{id}")
    public PersonaOutputDTO getById(@PathVariable Integer id) throws Exception {

        PersonaOutputDTO personaOutputDTO = personaInterfaz.buscarPorId(id);
        return personaOutputDTO;
    }

    @GetMapping("/name/{name}")
    public List<PersonaOutputDTO> getByUser(@PathVariable String name) throws Exception {

        List<PersonaOutputDTO> personaOutputDTOS = personaInterfaz.buscaPorUsuario(name);
        return personaOutputDTOS;
    }

    @PutMapping("/modify/{id}")
    public PersonaOutputDTO modificarUsuario(@PathVariable Integer id, @RequestBody Persona persona) throws Exception {

        PersonaOutputDTO personaOutputDTO = personaInterfaz.modificarUsuario(id, persona);
        System.out.println("Usuario modificado correctamente");
        return personaOutputDTO;
    }

    @DeleteMapping("/delete/{id}")
    public void eliminarUsuario(@PathVariable Integer id) throws Exception {
        personaInterfaz.eliminarUsuario(id);
        System.out.println("Usuario eliminado correctamente");
    }


    @GetMapping("/profesor/{id}")
    public ResponseEntity<ProfesorOutputDTO> getByIdProfesor(@PathVariable Integer id) throws Exception {
        ResponseEntity<ProfesorOutputDTO> responseEntity = new RestTemplate().getForEntity("http://localhost:8081/profesor/" + id, ProfesorOutputDTO.class);
        return ResponseEntity.ok(responseEntity.getBody());
    }
//
//    public ResponseEntity<ProfesorOutputDTO> getIdProfesorFeign(@PathVariable Integer id)  {
//        ResponseEntity<ProfesorOutputDTO> responseEntity = iFeignServer.getProfesorId(id);
//        return responseEntity;
//    }
//
    @GetMapping("/feign/{id}")
    ResponseEntity<ProfesorOutputDTO> getProfesorFeing(@PathVariable Integer id){
        System.out.println("En client Feing. Antes de llamada a server Profesor: "+id);
        ResponseEntity<ProfesorOutputDTO> rsFeing = iFeignServer.getIdProfesor(id);
        System.out.println("En client Feing. Despues de llamada a server");
        return rsFeing;

    }

}
