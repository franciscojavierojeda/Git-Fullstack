package com.example.ejemploJPA.infrastructure.repository.student;

import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.entidades.student.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepositorio extends JpaRepository<Student,Integer> {

    Student findByPersona(Persona persona);
}
