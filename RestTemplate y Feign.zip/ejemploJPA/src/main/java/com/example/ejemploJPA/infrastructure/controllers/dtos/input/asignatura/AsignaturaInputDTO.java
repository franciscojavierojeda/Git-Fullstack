package com.example.ejemploJPA.infrastructure.controllers.dtos.input.asignatura;

import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AsignaturaInputDTO {

    private Integer idAsignatura;
    private Integer idProfesor;
    private List<Integer> idStudents;
    private String asignatura;
    private String comments;
    private Date initialDate;
    private Date finishDate;

    public AsignaturaInputDTO(Asignatura asignatura) {
        this.idAsignatura = asignatura.getIdAsignatura();
        this.idProfesor = asignatura.getProfesor().getIdProfesor();
        List<Integer> studentsList=new ArrayList<>();
        for(Student student: asignatura.getStudents()){
            studentsList.add(student.getId());
        }
        this.idStudents=studentsList;
        this.asignatura = asignatura.getAsignatura();
        this.comments = asignatura.getComments();
        this.initialDate = asignatura.getInitialDate();
        this.finishDate = asignatura.getFinishDate();
    }
}
