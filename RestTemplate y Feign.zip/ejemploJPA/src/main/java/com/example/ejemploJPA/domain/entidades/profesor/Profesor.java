package com.example.ejemploJPA.domain.entidades.profesor;


import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.entidades.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Profesor {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer idProfesor;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_persona")
    private Persona persona;

    private String comments;

    @NotNull
    private String branch;

    @OneToMany(mappedBy = "idProfesor", cascade = CascadeType.PERSIST)
    private List<Student> students=new ArrayList<>();

    @OneToMany(mappedBy = "profesor", cascade = CascadeType.PERSIST)
    private List<Asignatura> asignaturas=new ArrayList<>();

}
