package com.example.ejemploJPA.application.interfaces.profesor;

import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.profesor.ProfesorInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.profesor.ProfesorOutputDTO;

import java.util.List;

public interface ProfesorInterfaz {


    ProfesorOutputDTO creaProfesor(ProfesorInputDTO profesorInputDTO);

    ProfesorOutputDTO buscarPorId(Integer id);


    ProfesorOutputDTO modificarProfesor(Integer id, ProfesorInputDTO profesorInputDTO);

    void eliminarProfesor(Integer id);

    List<ProfesorOutputDTO> findAll();

}
