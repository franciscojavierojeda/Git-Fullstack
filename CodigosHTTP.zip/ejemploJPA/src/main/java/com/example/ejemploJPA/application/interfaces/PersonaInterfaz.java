package com.example.ejemploJPA.application.interfaces;

import com.example.ejemploJPA.domain.Persona;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.PersonaOutputDTO;

import java.util.List;

public interface PersonaInterfaz {

    public PersonaOutputDTO creaPersona(PersonaInputDTO persona);

    public PersonaOutputDTO buscarPorId( Integer id) throws Exception;

    public List<PersonaOutputDTO> buscaPorUsuario(String name) throws Exception;

    public PersonaOutputDTO modificarUsuario(Integer id, Persona persona) throws Exception;

    public void eliminarUsuario(Integer id);

}
