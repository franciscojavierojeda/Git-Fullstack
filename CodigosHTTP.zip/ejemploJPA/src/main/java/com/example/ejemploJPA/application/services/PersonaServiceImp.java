package com.example.ejemploJPA.application.services;

import com.example.ejemploJPA.application.interfaces.PersonaInterfaz;
import com.example.ejemploJPA.domain.Persona;
import com.example.ejemploJPA.domain.exceptions.NotFoundException;
import com.example.ejemploJPA.domain.exceptions.UnprocesableException;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.PersonaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PersonaServiceImp implements PersonaInterfaz {

    @Autowired
    PersonaRepositorio personaRepositorio;

    public PersonaOutputDTO creaPersona(PersonaInputDTO personaInputDTO) {
        Persona p = new Persona(personaInputDTO);
        if (p.getUsuario().length() < 6 && p.getUsuario().length() > 10) {
            throw new UnprocesableException("El usuario debe tener entre 6 y 10 caracteres");
        }
        if (p.getPassword() == null) {
            throw new UnprocesableException("La contraseña no puede ser nula");
        }

        if (p.getName() == null) {
            throw new UnprocesableException("El nombre no puede ser nulo");
        }

        if (p.getName() == null) {
            throw new UnprocesableException("El nombre no puede ser nulo");
        }
        if (p.getSurname() == null) {
           throw new UnprocesableException("El apellido no puede ser nulo");
        }
        if (p.getCompanyEmail() == null) {
           throw new UnprocesableException("El email de empresa no puede ser nulo");
        }
        if (p.getPersonalEmail() == null) {
            throw new UnprocesableException("El email personal no puede ser nulo");
        }
        if (p.getCity() == null) {
            throw new UnprocesableException("La ciudad no puede ser nula");
        }
        if (p.getActiveBoolean() == null) {
             throw new UnprocesableException("El booleano no puede ser nulo");
        }

        if (p.getCreatedDate() == null) {
           throw new UnprocesableException("La fecha creada no puede ser nula");
        }
        personaRepositorio.save(p);
        PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(p);
        return personaOutputDTO;
    }

    public PersonaOutputDTO buscarPorId(Integer id) throws Exception {
        Persona persona = personaRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Id no encontrado"));
        PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(persona);
        return personaOutputDTO;
    }


    public List<PersonaOutputDTO> buscaPorUsuario(String name) throws Exception {
        List<PersonaOutputDTO> personasDTO = new ArrayList<>();
        List<Persona> personas = personaRepositorio.findByUsuario(name).orElseThrow(() -> new NotFoundException("Usuario no encontrado"));
        for (Persona persona : personas) {
            PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(persona);
            personasDTO.add(personaOutputDTO);
        }
        return personasDTO;
    }

    @Override
    public PersonaOutputDTO modificarUsuario(Integer id, Persona persona) throws Exception {
        Persona p = personaRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Id no encontrado"));
        if (persona.getUsuario().length() > 6 && persona.getUsuario().length() < 10) {
            p.setUsuario(persona.getUsuario());
        } else {
            throw new UnprocesableException("No se puede modificar el usuario");
        }
        if (persona.getPassword() != null) {
            p.setPassword(persona.getPassword());
        } else {
            throw new UnprocesableException("La contraseña no puede ser nula");
        }
        if (persona.getName() != null) {
            p.setName(persona.getName());
        } else {
            throw new UnprocesableException("El nombre no puede ser nulo");
        }
        if (persona.getSurname() != null) {
            p.setSurname(persona.getSurname());
        } else {
            throw new UnprocesableException("El apellido no puede ser nulo");
        }
        if (persona.getCompanyEmail() != null) {
            p.setCompanyEmail(persona.getCompanyEmail());
        } else {
            throw new UnprocesableException("El email de empresa no puede ser nulo");
        }
        if (persona.getPersonalEmail() != null) {
            p.setPersonalEmail(persona.getPersonalEmail());
        } else {
            throw new UnprocesableException("El email personal no puede ser nulo");
        }
        if (persona.getCity() != null) {
            p.setCity(persona.getCity());
        } else {
            throw new UnprocesableException("La ciudad no puede ser nula");
        }
        if (persona.getActiveBoolean() != null) {
            p.setActiveBoolean(persona.getActiveBoolean());
        } else {
            throw new UnprocesableException("El booleano no puede ser nulo");
        }

        if (persona.getCreatedDate() != null) {
            p.setCreatedDate(persona.getCreatedDate());
        } else {
            throw new UnprocesableException("La fecha creada no puede ser nula");
        }
        p.setUrlImage(persona.getUrlImage());
        p.setTerminationDate(persona.getTerminationDate());

        PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(p);
        personaRepositorio.saveAndFlush(p);
        return personaOutputDTO;
    }

    @Override
    public void eliminarUsuario(Integer id) {
        Persona p = personaRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Id no encontrado"));

        personaRepositorio.deleteById(id);
    }


}
