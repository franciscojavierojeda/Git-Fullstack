package com.example.ejemploJPA.domain.entidades.student;

import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.persona.Persona;
//import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    Integer id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_persona")
    private Persona persona;

    @NotNull(message = "Selecicone un numero de horas por semana valido")
    @Column(name = "horas_por_semana")
    private Integer numHoursWeek;

    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.PERSIST)
    private Profesor idProfesor;

    @NotNull(message = "Seleccione una rama valida")
    private String branch;

    @ManyToMany(fetch = FetchType.LAZY)
    private List<Asignatura> estudios;
}
