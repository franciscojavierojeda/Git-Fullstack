package com.example.ejemploJPA.domain.exceptions;

import java.util.Date;

public class CustomError {

    Date timestamp;
    int httpCode;
    String mensaje;

    public CustomError(Date timestamp,  String mensaje, int httpCode) {
        super();
        this.timestamp = timestamp;
        this.httpCode = httpCode;
        this.mensaje = mensaje;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public int getHttpCode() {
        return httpCode;
    }

    public String getMensaje() {
        return mensaje;
    }
}
