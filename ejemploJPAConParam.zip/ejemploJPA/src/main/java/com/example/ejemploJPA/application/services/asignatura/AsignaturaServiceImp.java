package com.example.ejemploJPA.application.services.asignatura;

import com.example.ejemploJPA.application.interfaces.asignatura.AsignaturaInterfaz;
import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.domain.exceptions.NotFoundException;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.asignatura.AsignaturaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.asignatura.AsignaturaOutputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.persona.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.asignatura.AsignaturaRepositorio;
import com.example.ejemploJPA.infrastructure.repository.profesor.ProfesorRepositorio;
import com.example.ejemploJPA.infrastructure.repository.student.StudentRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AsignaturaServiceImp implements AsignaturaInterfaz {

    @Autowired
    AsignaturaRepositorio asignaturaRepositorio;
    @Autowired
    ProfesorRepositorio profesorRepositorio;
    @Autowired
    StudentRepositorio studentRepositorio;

    @Override
    public AsignaturaOutputDTO creaAsignatura(AsignaturaInputDTO asignaturaInputDTO) {
        Asignatura asignatura = inputToAsignatura(asignaturaInputDTO);

        asignaturaRepositorio.save(asignatura);

        AsignaturaOutputDTO asignaturaOutputDTO= new AsignaturaOutputDTO(asignatura);
        return asignaturaOutputDTO;
    }

    private Asignatura inputToAsignatura(AsignaturaInputDTO asignaturaInputDTO) {
        Asignatura asignatura = new Asignatura();
        asignatura.setAsignatura(asignaturaInputDTO.getAsignatura());
        asignatura.setProfesor(profesorRepositorio.findByIdProfesor(asignaturaInputDTO.getIdProfesor()));
        asignatura.setComments(asignaturaInputDTO.getComments());
        asignatura.setInitialDate(asignaturaInputDTO.getInitialDate());
        asignatura.setFinishDate(asignaturaInputDTO.getFinishDate());

        List<Student> studentsList = new ArrayList<>();
        for (Integer student : asignaturaInputDTO.getIdStudents()) {
            Student stu=studentRepositorio.findById(student).orElseThrow(()-> new NotFoundException("Id no encontrado"));
            asignatura.getStudents().add(stu);
        }
        return asignatura;

    }

    @Override
    public List<AsignaturaOutputDTO> findAll() {
        return null;
    }

    @Override
    public AsignaturaOutputDTO buscarPorId(Integer id) {
        Asignatura asignatura = asignaturaRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Id no encontrado"));
        AsignaturaOutputDTO asignaturaOutputDTO = new AsignaturaOutputDTO(asignatura);
        return asignaturaOutputDTO;
    }

    @Override
    public AsignaturaOutputDTO modificarAsignatura(Integer id, AsignaturaInputDTO asignaturaInputDTO) {
        Asignatura asignatura = asignaturaRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Id no encontrado"));
        if(asignaturaInputDTO.getAsignatura()!=null){
            asignatura.setAsignatura(asignaturaInputDTO.getAsignatura());
        }
        if(asignaturaInputDTO.getComments()!=null){
            asignatura.setComments(asignaturaInputDTO.getComments());
        }
        if(asignaturaInputDTO.getIdStudents()!=null){
            List<Student> students=new ArrayList<>();
            for(Integer intStudents: asignaturaInputDTO.getIdStudents()){
                Student stu=studentRepositorio.findById(intStudents).orElseThrow(()-> new NotFoundException("Asignatura no encontrada"));
                students.add(stu);
            }
            asignatura.setStudents(students);
        }
        if(asignaturaInputDTO.getIdProfesor()!=null){
            Profesor profesor=profesorRepositorio.findById(asignaturaInputDTO.getIdProfesor()).orElseThrow(()-> new NotFoundException("Profesor no encontrado"));
            asignatura.setProfesor(profesor);
        }
        if(asignaturaInputDTO.getInitialDate()!=null){
            asignatura.setInitialDate(asignaturaInputDTO.getInitialDate());
        }
        if(asignaturaInputDTO.getFinishDate()!=null){
            asignatura.setFinishDate(asignaturaInputDTO.getFinishDate());
        }
        asignaturaRepositorio.save(asignatura);
        AsignaturaOutputDTO asignaturaOutputDTO=new AsignaturaOutputDTO(asignatura);
        return asignaturaOutputDTO;
    }

    @Override
    public void eliminarAsignatura(Integer id) {
        Asignatura asignatura = asignaturaRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Id no encontrado"));
        asignaturaRepositorio.delete(asignatura);
    }

    @Override
    public List<AsignaturaOutputDTO> getAsignaturasEstudent(Integer id) {
        Student student=studentRepositorio.findById(id).orElseThrow(()-> new NotFoundException("Student no encontrado"));
        List<AsignaturaOutputDTO> asignaturasOutputDTO=new ArrayList<>();
        if(student.getEstudios()!=null) {
            for (Asignatura asignatura : student.getEstudios()) {
                AsignaturaOutputDTO asignaturaOutputDTO = new AsignaturaOutputDTO(asignatura);
                asignaturasOutputDTO.add(asignaturaOutputDTO);
            }
        }
        else
            throw new NotFoundException("Lista de asihnaturas vacia");
        return asignaturasOutputDTO;

    }
}
