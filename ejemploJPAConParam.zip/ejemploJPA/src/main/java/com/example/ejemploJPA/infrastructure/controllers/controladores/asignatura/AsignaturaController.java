package com.example.ejemploJPA.infrastructure.controllers.controladores.asignatura;


import com.example.ejemploJPA.application.interfaces.asignatura.AsignaturaInterfaz;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.asignatura.AsignaturaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.asignatura.AsignaturaOutputDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("asignatura")
public class AsignaturaController {

    @Autowired
    AsignaturaInterfaz asignaturaInterfaz;

    @GetMapping("/getHola")
    public String getHello() {
        return "hola";
    }

    @PostMapping
    public AsignaturaOutputDTO anadirAsignatura(@RequestBody AsignaturaInputDTO asignaturaInputDTO){
        System.out.println("Vamos a anadir una asignatura");
        AsignaturaOutputDTO asignaturaOutputDTO = asignaturaInterfaz.creaAsignatura(asignaturaInputDTO);
        return asignaturaOutputDTO;
    }

    @GetMapping
    public List<AsignaturaOutputDTO> getAll() throws Exception {

        List<AsignaturaOutputDTO> asignaturaOutputDTOS = asignaturaInterfaz.findAll();
        return asignaturaOutputDTOS;
    }

    @GetMapping("/asignaturas/{id}")
    public List<AsignaturaOutputDTO> getAsignaturasEstudent(@PathVariable Integer id) throws Exception {

        List<AsignaturaOutputDTO> asignaturaOutputDTOS = asignaturaInterfaz.getAsignaturasEstudent(id);
        return asignaturaOutputDTOS;
    }

    @GetMapping("/{id}")
    public AsignaturaOutputDTO getById(@PathVariable Integer id) throws Exception {

        AsignaturaOutputDTO asignaturaOutputDTO = asignaturaInterfaz.buscarPorId(id);
        return asignaturaOutputDTO;
    }

    @PutMapping("/{id}")
    public AsignaturaOutputDTO modificarAsignatura(@PathVariable Integer id, @RequestBody AsignaturaInputDTO asignaturaInputDTO) throws Exception {
        AsignaturaOutputDTO asignaturaOutputDTO = asignaturaInterfaz.modificarAsignatura(id,asignaturaInputDTO);
        System.out.println("Asignatura modificada correctamente");
        return asignaturaOutputDTO;
    }

    @DeleteMapping("/{id}")
    public void eliminarAsignatura(@PathVariable Integer id) throws Exception {
        asignaturaInterfaz.eliminarAsignatura(id);
        System.out.println("Asignatura eliminada correctamente");
    }

}
