package com.example.ejemploJPA.infrastructure.controllers.dtos.input.student;


import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentInputDTO {

    Integer id;
    Integer idPersona;
    Integer numHoursWeek;
    Integer idProfesor;
    String branch;
    List<Integer> estudios;

    public StudentInputDTO(Student student) {
        this.id = student.getId();
        this.idPersona = Integer.valueOf(student.getPersona().getId());
        this.numHoursWeek = student.getNumHoursWeek();
        this.idProfesor = student.getIdProfesor().getIdProfesor();
        this.branch = student.getBranch();

    }
}
