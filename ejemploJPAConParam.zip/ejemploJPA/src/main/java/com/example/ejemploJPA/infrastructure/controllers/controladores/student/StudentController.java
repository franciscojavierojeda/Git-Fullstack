package com.example.ejemploJPA.infrastructure.controllers.controladores.student;

import com.example.ejemploJPA.application.interfaces.persona.PersonaInterfaz;
import com.example.ejemploJPA.application.interfaces.student.StudentInterfaz;
import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.student.StudentInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.persona.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.student.StudentOutputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.student.StudentPersonaOutputDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("student")
public class StudentController {

    @Autowired
    StudentInterfaz studentInterfaz;
    @Autowired
    PersonaInterfaz personaInterfaz;

    @GetMapping("/getHola")
    public String getHello() {
        return "hola";
    }

    @PostMapping("/anadirStudent")
    public StudentOutputDTO anadirStudent(@RequestBody StudentInputDTO studentInputDTO) {
        System.out.println("Vamos a anadir el estudiante");
        StudentOutputDTO studentOutputDTO = studentInterfaz.creaStudent(studentInputDTO);
        return studentOutputDTO;
    }


    @GetMapping
    public List<StudentOutputDTO> getAll() throws Exception {

        List<StudentOutputDTO> studentsOutputDTO = studentInterfaz.findAll();
        return studentsOutputDTO;
    }

    @GetMapping("/{id}")
    public String findById(@PathVariable Integer id, @Value("simple") @RequestParam(name = "parametro", defaultValue = "simple") String parametro) throws Exception {

        StudentOutputDTO studentOutputDTO = studentInterfaz.buscarPorId(id);

        switch (parametro) {
            case "simple": {
                return studentOutputDTO.toString();
            }
            case "full": {
                StudentPersonaOutputDTO studentPersonaOutputDTO = new StudentPersonaOutputDTO(studentOutputDTO);
                Integer idPersona=studentPersonaOutputDTO.getIdPersona();
                Persona persona=studentInterfaz.buscarPorIdPersona(idPersona);
                studentPersonaOutputDTO.setPersona(persona);
                return studentPersonaOutputDTO.toString();
            }
        }
        //   switch (parametro.toLowerCase()) {

//            case "simple": {
//                StudentOutputDTO studentOutputDTO = studentInterfaz.buscarPorId(id);
//
//            }
//            case "full": {
//                StudentOutputDTO studentOutputDTO = studentInterfaz.buscarPorId(id);
//                return student;
//            }
//        }
        return "vacio";
    }

    @PutMapping("/modify/{id}")
    public StudentOutputDTO modificarStudent(@PathVariable Integer id, @RequestBody StudentInputDTO studentInputDTO) throws Exception {
        System.out.println("Estudiante modificado correctamente");
        StudentOutputDTO studentOutputDTO = studentInterfaz.modificarStudent(id, studentInputDTO);
        System.out.println("Estudiante modificado correctamente");
        return studentOutputDTO;
    }

    @DeleteMapping("/{id}")
    public void eliminarStudent(@PathVariable Integer id) throws Exception {
        studentInterfaz.eliminarStudent(id);
        System.out.println("Usuario eliminado correctamente");
    }


}
