package com.example.ejemploJPA.domain.entidades.persona;

import com.example.ejemploJPA.infrastructure.controllers.dtos.input.persona.PersonaInputDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Persona {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    Integer id;

    String password;
    String usuario;
    String name;
    String surname;
    String companyEmail;
    String personalEmail;
    String city;
    Boolean activeBoolean;
    Date createdDate;
    String urlImage;
    Date terminationDate;


    public Persona(PersonaInputDTO personaInputDTO) {
        this.id = personaInputDTO.getId();
        this.usuario = personaInputDTO.getUsuario();
        this.password=personaInputDTO.getPassword();
        this.name = personaInputDTO.getName();
        this.surname = personaInputDTO.getSurname();
        this.companyEmail = personaInputDTO.getCompanyEmail();
        this.personalEmail = personaInputDTO.getPersonalEmail();
        this.city = personaInputDTO.getCity();
        this.activeBoolean = personaInputDTO.getActiveBoolean();
        this.createdDate = personaInputDTO.getCreatedDate();
        this.urlImage = personaInputDTO.getUrlImage();
        this.terminationDate = personaInputDTO.getTerminationDate();
    }
}
