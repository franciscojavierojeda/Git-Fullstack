package com.example.ejemploJPA.infrastructure.controllers.dtos.output.student;

import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentOutputDTO {

    Integer id;
    Integer idPersona;
    Integer numHoursWeek;
    Integer idProfesor;
    String branch;
    List<String> estudios;

    public StudentOutputDTO(Student student) {
        this.id=student.getId();
        this.idPersona =student.getPersona().getId();
        this.numHoursWeek = student.getNumHoursWeek();
        this.idProfesor =student.getIdProfesor().getIdProfesor();
        this.branch = student.getBranch();
        List<String> listaNombres=new ArrayList<>();
        if(student.getEstudios()!=null) {
            for (Asignatura nombre : student.getEstudios()) {
                listaNombres.add(nombre.getAsignatura());
            }
            this.estudios = listaNombres;
        }
    }

}
