package com.example.ejemploJPA.application.services.profesor;

import com.example.ejemploJPA.application.interfaces.profesor.ProfesorInterfaz;
import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.domain.exceptions.NotFoundException;
import com.example.ejemploJPA.domain.exceptions.UnprocesableException;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.profesor.ProfesorInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.profesor.ProfesorOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.persona.PersonaRepositorio;
import com.example.ejemploJPA.infrastructure.repository.profesor.ProfesorRepositorio;
import com.example.ejemploJPA.infrastructure.repository.student.StudentRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ProfesorServiceImp implements ProfesorInterfaz {

    @Autowired
    StudentRepositorio studentRepositorio;
    @Autowired
    ProfesorRepositorio profesorRepositorio;
    @Autowired
    PersonaRepositorio personaRepositorio;

    @Override
    public ProfesorOutputDTO creaProfesor(ProfesorInputDTO profesorInputDTO) {
        Profesor profesor = inputToProfesor(profesorInputDTO);
        Student studentRepetido = studentRepositorio.findByPersona(profesor.getPersona());

        Profesor profesorRepetido = profesorRepositorio.findByPersona(profesor.getPersona());
        if (studentRepetido != null && studentRepetido.getPersona() == profesor.getPersona()) {
            throw new UnprocesableException("El profesor ya es un estudiante");
        }
        if (profesorRepetido != null && profesorRepetido.getPersona() == profesor.getPersona()) {
            throw new UnprocesableException("El profesor ya coincide con ese codigo de persona");
        }
        profesorRepositorio.save(profesor);

        ProfesorOutputDTO profesorOutputDTO = new ProfesorOutputDTO(profesor);
        return profesorOutputDTO;
    }

    public Profesor inputToProfesor(ProfesorInputDTO profesorInputDTO) {
        Profesor profesor = new Profesor();

        profesor.setIdProfesor(profesorInputDTO.getIdProfesor());
        profesor.setPersona(personaRepositorio.findById(profesorInputDTO.getIdPersona()).orElseThrow(() -> new NotFoundException("No existe el id de persona")));
        profesor.setBranch(profesorInputDTO.getBranch());
        profesor.setComments(profesorInputDTO.getComments());
        profesor.setStudents(profesorInputDTO.getStudents());

        return profesor;
    }

    @Override
    public ProfesorOutputDTO buscarPorId(Integer id) {
        Profesor profesor = profesorRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Error: Profesor no encontrado"));
        ProfesorOutputDTO asignaturaOutputDTO = new ProfesorOutputDTO(profesor);

        return asignaturaOutputDTO;
    }



    @Override
    public ProfesorOutputDTO modificarProfesor(Integer id, ProfesorInputDTO profesorInputDTO) {
        Profesor profesor = profesorRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Error: Profesor no encontrado"));
        profesor.setPersona(personaRepositorio.findById(profesorInputDTO.getIdPersona()).orElseThrow(() ->new NotFoundException("Persona no encontrada vinculada con profesor")));
        if(profesorInputDTO.getBranch()!=null){
            profesor.setBranch(profesorInputDTO.getBranch());
        }
        if(profesorInputDTO.getComments()!=null){
            profesor.setComments(profesorInputDTO.getComments());
        }
        if(profesorInputDTO.getStudents()!=null){
            profesor.setStudents(profesorInputDTO.getStudents());
        }
        ProfesorOutputDTO asignaturaOutputDTO =new ProfesorOutputDTO(profesor);

        profesorRepositorio.save(profesor);
        return asignaturaOutputDTO;
    }


    @Override
    public void eliminarProfesor(Integer id) {
        Profesor profesor = profesorRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Estudiante no encontrado"));
        if(!profesor.getStudents().isEmpty()){
            throw new UnprocesableException("No se puede eliminar a un profesor si tiene estudiantes asignados");
        }
        profesorRepositorio.deleteById(id);
    }

    @Override
    public List<ProfesorOutputDTO> findAll() {
        List<Profesor> profesors=profesorRepositorio.findAll();
        List<ProfesorOutputDTO> asignaturaOutputDTOS = profesors.stream().map(p->new ProfesorOutputDTO(p)).collect(Collectors.toList());
        return asignaturaOutputDTOS;
    }


}
