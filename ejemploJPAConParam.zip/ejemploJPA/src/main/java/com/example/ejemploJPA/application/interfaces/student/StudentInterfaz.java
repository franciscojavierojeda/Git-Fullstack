package com.example.ejemploJPA.application.interfaces.student;

import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.persona.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.student.StudentInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.persona.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.student.StudentOutputDTO;

import java.util.List;

public interface StudentInterfaz {

    public StudentOutputDTO creaStudent(StudentInputDTO student);

    public StudentOutputDTO buscarPorId( Integer id) throws Exception;

    public StudentOutputDTO modificarStudent(Integer id, StudentInputDTO studentInputDTO) throws Exception;

    public void eliminarStudent(Integer id);

    List<StudentOutputDTO> findAll();

    Persona buscarPorIdPersona(Integer idPersona) throws Exception;
}
