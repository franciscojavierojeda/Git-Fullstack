package com.example.ejemploJPA.infrastructure.controllers.dtos.output.profesor;

import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.StudentOutputNoProfesorDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfesorOutputDTO {

    private Integer idProfesor;
    private Integer idPersona;
    private String comments;
    private String branch;
    private List<StudentOutputNoProfesorDTO> students;

    public ProfesorOutputDTO(Profesor profesor) {
        this.idProfesor = profesor.getIdProfesor();
        this.idPersona = profesor.getPersona().getId();
        this.comments = profesor.getComments();
        this.branch = profesor.getBranch();
        List<StudentOutputNoProfesorDTO> studentsList=new ArrayList<>();
        if (profesor.getStudents() != null) {
            for (Student studentsDTO : profesor.getStudents()) {
                StudentOutputNoProfesorDTO studentOutputNoProfesorDTO = new StudentOutputNoProfesorDTO(studentsDTO);
                studentsList.add(studentOutputNoProfesorDTO);
            }
        }
        this.students=studentsList;

    }

}
