package com.example.ejemploJPA.infrastructure.controllers;

import com.example.ejemploJPA.domain.Persona;
import com.example.ejemploJPA.application.interfaces.PersonaInterfaz;
import com.example.ejemploJPA.infrastructure.controllers.dtos.PersonaDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.PersonaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Controlador {

    @Autowired
    PersonaRepositorio personaRepositorio;

    @Autowired
    PersonaInterfaz personaInterfaz;

    @GetMapping
    public List<Persona> getHola() {
        return personaRepositorio.findAll();
    }

    @PostMapping
    public PersonaOutputDTO anadirUsuario(@RequestBody PersonaInputDTO personaInputDTO) {
        PersonaOutputDTO personaOutputDTO = personaInterfaz.creaPersona(personaInputDTO);
        System.out.println("Usuario anadido correctamente");
        return personaOutputDTO;
    }

    @GetMapping("/usuario/{id}")
    public PersonaOutputDTO getById(@PathVariable Integer id) throws Exception {

         PersonaOutputDTO personaOutputDTO = personaInterfaz.buscarPorId(id);
        return personaOutputDTO;
    }

    @GetMapping("/name/{name}")
    public List<PersonaOutputDTO> getByUser(@PathVariable String name) throws Exception {

        List<PersonaOutputDTO> personaOutputDTOS = personaInterfaz.buscaPorUsuario(name);
        return personaOutputDTOS;
    }

    @PutMapping("/modify/{id}")
    public PersonaOutputDTO modificarUsuario(@PathVariable Integer id, @RequestBody Persona persona) throws Exception {

        PersonaOutputDTO personaOutputDTO = personaInterfaz.modificarUsuario(id, persona);
        System.out.println("Usuario modificado correctamente");
        return personaOutputDTO;
    }

    @DeleteMapping("/delete/{id}")
    public void eliminarUsuario(@PathVariable Integer id) throws Exception {
         personaInterfaz.eliminarUsuario(id);
        System.out.println("Usuario eliminado correctamente");
    }


}
