package com.example.ejemploJPA.application.services;

import com.example.ejemploJPA.application.interfaces.PersonaInterfaz;
import com.example.ejemploJPA.domain.Persona;
import com.example.ejemploJPA.infrastructure.controllers.dtos.PersonaDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.PersonaOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.PersonaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PersonaServiceImp implements PersonaInterfaz {

    @Autowired
    PersonaRepositorio personaRepositorio;

    public PersonaOutputDTO creaPersona(PersonaInputDTO personaInputDTO) {
        Persona persona= new Persona(personaInputDTO);
        personaRepositorio.save(persona);
        PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(persona);
        return personaOutputDTO;
    }

    public PersonaOutputDTO buscarPorId( Integer id) throws Exception{
        Persona persona = personaRepositorio.findById(id).orElseThrow(() -> new Exception("Id no encontrado"));
        PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(persona);
        return personaOutputDTO;
    }


    public List<PersonaOutputDTO> buscaPorUsuario(String name) throws Exception {
        List<PersonaOutputDTO> personasDTO = new ArrayList<>();
        List<Persona> personas = personaRepositorio.findByUsuario(name).orElseThrow(() -> new Exception("Usuario no encontrado"));
        for (Persona persona : personas) {
            PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(persona);
            personasDTO.add(personaOutputDTO);
        }
        return personasDTO;
    }

    @Override
    public PersonaOutputDTO modificarUsuario(Integer id, Persona persona) throws Exception {
        Persona p = personaRepositorio.findById(id).orElseThrow(() -> new Exception("Id no encontrado"));
        //Tengo que modificar uno a uno viendo si son nulos
        if (persona.getUsuario().length()>6 && persona.getUsuario().length()<10) {
            p.setUsuario(persona.getUsuario());
        }
        else{
            throw new Exception("No se puede modificar el usuario");
        }
        if (persona.getPassword() != null) {
            p.setPassword(persona.getPassword());
        }
        if (persona.getName() != null) {
            p.setName(persona.getName());
        }
        if (persona.getSurname() != null) {
            p.setSurname(persona.getSurname());
        }
        if (persona.getCompanyEmail() != null) {
            p.setCompanyEmail(persona.getCompanyEmail());
        }
        if (persona.getPersonalEmail() != null) {
            p.setPersonalEmail(persona.getPersonalEmail());
        }
        if (persona.getCity() != null) {
            p.setCity(persona.getCity());
        }
        if (persona.getActiveBoolean() != null) {
            p.setActiveBoolean(persona.getActiveBoolean());
        }
        if (persona.getUsuario() != null) {
            p.setUsuario(persona.getUsuario());
        }
        if (persona.getCreatedDate() != null) {
            p.setCreatedDate(persona.getCreatedDate());
        }
        p.setUrlImage(persona.getUrlImage());
        p.setTerminationDate(persona.getTerminationDate());

        PersonaOutputDTO personaOutputDTO = new PersonaOutputDTO(p);
        personaRepositorio.saveAndFlush(p);
        return personaOutputDTO;
    }

    @Override
    public void eliminarUsuario(Integer id) {
        personaRepositorio.deleteById(id);
    }


}
