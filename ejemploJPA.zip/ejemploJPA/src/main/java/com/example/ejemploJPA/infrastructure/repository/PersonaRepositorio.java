package com.example.ejemploJPA.infrastructure.repository;

import com.example.ejemploJPA.domain.Persona;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PersonaRepositorio extends JpaRepository<Persona,Integer> {


    Optional<List<Persona>> findByUsuario(String usuario);
}
