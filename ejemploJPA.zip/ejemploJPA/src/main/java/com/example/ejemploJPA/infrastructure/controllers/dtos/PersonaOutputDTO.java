package com.example.ejemploJPA.infrastructure.controllers.dtos;

import com.example.ejemploJPA.domain.Persona;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonaOutputDTO {
    Integer id;
    String usuario;
    String name;
    String surname;
    String companyEmail;
    String personalEmail;
    String city;
    Boolean activeBoolean;
    Date createdDate;
    String urlImage;
    Date terminationDate;

    public PersonaOutputDTO(Persona persona) {
        this.id = persona.getId();
        this.usuario = persona.getUsuario();
        this.name = persona.getName();
        this.surname = persona.getSurname();
        this.companyEmail = persona.getCompanyEmail();
        this.personalEmail = persona.getPersonalEmail();
        this.city = persona.getCity();
        this.activeBoolean = persona.getActiveBoolean();
        this.createdDate = persona.getCreatedDate();
        this.urlImage = persona.getUrlImage();
        this.terminationDate = persona.getTerminationDate();
    }
}
