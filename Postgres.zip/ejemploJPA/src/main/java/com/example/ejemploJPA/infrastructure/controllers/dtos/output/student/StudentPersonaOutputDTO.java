package com.example.ejemploJPA.infrastructure.controllers.dtos.output.student;

import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.exceptions.NotFoundException;
import com.example.ejemploJPA.infrastructure.repository.persona.PersonaRepositorio;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentPersonaOutputDTO extends StudentOutputDTO {



    Integer id;
    Integer idPersona;
    Integer numHoursWeek;
    Integer idProfesor;
    String branch;
    List<String> estudios;
    Persona persona;

    public StudentPersonaOutputDTO(StudentOutputDTO student) throws Exception {
        this.id=student.getId();
        this.idPersona= student.getIdPersona();
        this.numHoursWeek = student.getNumHoursWeek();
        this.idProfesor =student.getIdProfesor();
        this.branch = student.getBranch();
        this.estudios=student.getEstudios();
    }

}
