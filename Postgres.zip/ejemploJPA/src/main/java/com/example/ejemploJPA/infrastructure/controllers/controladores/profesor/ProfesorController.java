

package com.example.ejemploJPA.infrastructure.controllers.controladores.profesor;

import com.example.ejemploJPA.application.interfaces.profesor.ProfesorInterfaz;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.profesor.ProfesorInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.profesor.ProfesorOutputDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/profesor")//Modificar los verbos REST
public class ProfesorController {

    @Autowired
    ProfesorInterfaz profesorInterfaz;

    @GetMapping("/getHola")
    public String getHello() {
        return "hola";
    }

    @PostMapping
    public ProfesorOutputDTO anadirProfesor(@RequestBody ProfesorInputDTO profesorInputDTO){
        System.out.println("Vamos a anadir el profesor");
        ProfesorOutputDTO asignaturaOutputDTO =profesorInterfaz.creaProfesor(profesorInputDTO);
        return asignaturaOutputDTO;
    }

    @GetMapping
    public List<ProfesorOutputDTO> getAll() throws Exception {

        List<ProfesorOutputDTO> asignaturaOutputDTOS = profesorInterfaz.findAll();
        return asignaturaOutputDTOS;
    }

    @GetMapping("/{id}")
    public ProfesorOutputDTO getById(@PathVariable Integer id) throws Exception {

        ProfesorOutputDTO asignaturaOutputDTO = profesorInterfaz.buscarPorId(id);
        return asignaturaOutputDTO;
    }

    @PutMapping("/{id}")
    public ProfesorOutputDTO modificarProfesor(@PathVariable Integer id, @RequestBody ProfesorInputDTO profesorInputDTO) throws Exception {
        ProfesorOutputDTO asignaturaOutputDTO = profesorInterfaz.modificarProfesor(id,profesorInputDTO);
        System.out.println("Estudiante modificado correctamente");
        return asignaturaOutputDTO;
    }

    @DeleteMapping("/{id}")
    public void eliminarProfesor(@PathVariable Integer id) throws Exception {
        profesorInterfaz.eliminarProfesor(id);
        System.out.println("Profesor eliminado correctamente");
    }



}
