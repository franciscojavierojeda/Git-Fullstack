package com.example.perfiles;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PropertySource({"classpath:myconfiguration.yml","classpath:application.properties"})
public class ControladorPerfil {

    @Value("${user}")
    private String usuario;

    @Value("${password}")
    private String password;

    @Value("${valor1}")
    private String valor1;

    @Value("${valor2}")
    private String valor2;

    @GetMapping("/parametros")
    public String datoUsuario(){
        return "Usuario: " + usuario + " y contraseña: "+ password + " y el otro usuario es: " + valor1 + valor2;
    }


}
