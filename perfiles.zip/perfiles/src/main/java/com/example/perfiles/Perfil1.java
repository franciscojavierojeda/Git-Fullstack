package com.example.perfiles;

import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Component
@Profile("perfil1")
@RestController
@PropertySource({"classpath:myconfiguration.yml","classpath:application.properties"})
public class Perfil1 implements PerfilInterface{

    String perfil="perfil1";
    @Override
    @GetMapping("/perfil")
    public void miFuncion() {
    System.out.println("Perfil uno");
    }
}
