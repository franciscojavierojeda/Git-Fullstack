package com.example.perfiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfilesApplication.class, args);
	}

}
