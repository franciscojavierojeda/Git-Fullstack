package com.example.perfiles;

public interface PerfilInterface {
    public void miFuncion();
}
