package com.example.perfiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
