package com.example.ejemploJPA.application.interfaces.persona;

import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.persona.PersonaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.persona.PersonaOutputDTO;

import java.util.List;

public interface PersonaInterfaz {

    public PersonaOutputDTO creaPersona(PersonaInputDTO persona);

    public PersonaOutputDTO buscarPorId( Integer id) throws Exception;

    public List<PersonaOutputDTO> buscaPorUsuario(String name) throws Exception;

    public PersonaOutputDTO modificarUsuario(Integer id, Persona persona) throws Exception;

    public void eliminarUsuario(Integer id);

}
