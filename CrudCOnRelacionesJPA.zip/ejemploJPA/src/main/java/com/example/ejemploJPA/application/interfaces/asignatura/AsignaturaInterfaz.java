package com.example.ejemploJPA.application.interfaces.asignatura;

import com.example.ejemploJPA.infrastructure.controllers.dtos.input.asignatura.AsignaturaInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.asignatura.AsignaturaOutputDTO;

import java.util.List;

public interface AsignaturaInterfaz {
    AsignaturaOutputDTO creaAsignatura(AsignaturaInputDTO asignaturaInputDTO);

    List<AsignaturaOutputDTO> findAll();

    AsignaturaOutputDTO buscarPorId(Integer id);

    AsignaturaOutputDTO modificarAsignatura(Integer id, AsignaturaInputDTO asignaturaInputDTO);

    void eliminarAsignatura(Integer id);

    List<AsignaturaOutputDTO> getAsignaturasEstudent(Integer id);

}
