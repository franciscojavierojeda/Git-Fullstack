package com.example.ejemploJPA.infrastructure.repository.profesor;

import com.example.ejemploJPA.domain.entidades.persona.Persona;
import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepositorio extends JpaRepository<Profesor,Integer> {


    Profesor findByIdProfesor(Integer idProfesor);

    Profesor findByPersona(Persona persona);
}
