package com.example.ejemploJPA.domain.entidades.asignatura;

import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.asignatura.AsignaturaInputDTO;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "estudios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Asignatura {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id_asignatura")
    private Integer idAsignatura;

    @ManyToOne(cascade = CascadeType.PERSIST)
    private Profesor profesor;

    @ManyToMany(mappedBy = "estudios",cascade = CascadeType.PERSIST)
    private List<Student> students = new ArrayList<>();

    String asignatura;

    String comments;
    @NotNull
    @Column(name = "initial_date")
    Date initialDate;
    @Column(name = "finish_date")
    Date finishDate;


}

