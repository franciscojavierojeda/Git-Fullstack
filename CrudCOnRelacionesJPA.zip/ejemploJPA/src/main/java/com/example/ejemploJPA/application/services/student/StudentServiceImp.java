package com.example.ejemploJPA.application.services.student;

import com.example.ejemploJPA.application.interfaces.profesor.ProfesorInterfaz;
import com.example.ejemploJPA.application.interfaces.student.StudentInterfaz;
import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.profesor.Profesor;
import com.example.ejemploJPA.domain.entidades.student.Student;
import com.example.ejemploJPA.domain.exceptions.NotFoundException;
import com.example.ejemploJPA.domain.exceptions.UnprocesableException;
import com.example.ejemploJPA.infrastructure.controllers.dtos.input.student.StudentInputDTO;
import com.example.ejemploJPA.infrastructure.controllers.dtos.output.student.StudentOutputDTO;
import com.example.ejemploJPA.infrastructure.repository.asignatura.AsignaturaRepositorio;
import com.example.ejemploJPA.infrastructure.repository.persona.PersonaRepositorio;
import com.example.ejemploJPA.infrastructure.repository.profesor.ProfesorRepositorio;
import com.example.ejemploJPA.infrastructure.repository.student.StudentRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class StudentServiceImp implements StudentInterfaz {

    @Autowired
    StudentRepositorio studentRepositorio;
    @Autowired
    ProfesorRepositorio profesorRepositorio;
    @Autowired
    PersonaRepositorio personaRepositorio;

    @Autowired
    AsignaturaRepositorio asignaturaRepositorio;
    @Autowired
    ProfesorInterfaz profesorInterfaz;


    @Override
    public StudentOutputDTO creaStudent(StudentInputDTO studentInputDTO) {
        Student student = inputToStudent(studentInputDTO);
        Student studentRepetido=studentRepositorio.findByPersona(student.getPersona());
        Profesor profesorRepetido=profesorRepositorio.findByPersona(student.getPersona());

        if(profesorRepetido!=null && profesorRepetido.getPersona()==student.getPersona() ){
            throw new UnprocesableException("El estudiante ya es un profesor");
        }

        if(studentRepetido!= null && studentRepetido.getPersona()==student.getPersona()){
            throw new UnprocesableException("El estudiante ya coincide con ese codigo de persona");
        }
        studentRepositorio.save(student);

        StudentOutputDTO studentOutputDTO = new StudentOutputDTO(student);
        return studentOutputDTO;
    }

    public Student inputToStudent(StudentInputDTO studentInputDTO) {
        Student student = new Student();

        student.setId(studentInputDTO.getId());
        student.setPersona(personaRepositorio.findById(studentInputDTO.getIdPersona()).orElseThrow(() -> new NotFoundException("No existe el id de persona")));
        student.setNumHoursWeek(studentInputDTO.getNumHoursWeek());
        student.setIdProfesor(profesorRepositorio.findByIdProfesor(studentInputDTO.getIdProfesor()));
        student.setBranch(studentInputDTO.getBranch());
        List<Asignatura> asignaturaList=new ArrayList<>();
        if(studentInputDTO.getEstudios()!=null) {
            for (Integer asignatura : studentInputDTO.getEstudios()) {
                Asignatura asi = asignaturaRepositorio.findById(asignatura).orElseThrow(() -> new NotFoundException("Asignatura no encontrada"));
                asignaturaList.add(asi);
            }
            student.setEstudios(asignaturaList);
        }
        if (studentInputDTO.getIdPersona() == null) {
            throw new UnprocesableException("El id de persona no puede ser nulo");
        }

        if (studentInputDTO.getIdProfesor() == null) {
            throw new UnprocesableException("El id de profesor no puede ser nulo");
        }

        return student;
    }


    @Override
    public StudentOutputDTO buscarPorId(Integer id) throws Exception {
        Student student = studentRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Error: Estudiante no encontrado"));
        StudentOutputDTO studentOutputDTO = new StudentOutputDTO(student);

        return studentOutputDTO;
    }


    @Override
    public StudentOutputDTO modificarStudent(Integer id,StudentInputDTO studentInputDTO) throws Exception {
        Student student = studentRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Error: Estudiante no encontrado"));
        student.setPersona(personaRepositorio.findById(studentInputDTO.getIdPersona()).orElseThrow(() ->new NotFoundException("Persona no encontrada vinculada con estudiante")));
        student.setBranch(studentInputDTO.getBranch());
        student.setNumHoursWeek(studentInputDTO.getNumHoursWeek());
      //  student.setIdProfesor(profesorRepositorio.findByIdProfesor(studentInputDTO.getIdProfesor()));
        List<Asignatura> asignaturaList=new ArrayList<>();
        for(Integer asignatura: studentInputDTO.getEstudios()){
            Asignatura asi=asignaturaRepositorio.findById(asignatura).orElseThrow(() -> new NotFoundException("Asignatura no encontrada"));
            asignaturaList.add(asi);
        }
        student.setEstudios(asignaturaList);
        StudentOutputDTO studentOutputDTO = new StudentOutputDTO(student);
        studentRepositorio.save(student);
        return studentOutputDTO;
    }


    @Override
    public void eliminarStudent(Integer id) {
        Student student = studentRepositorio.findById(id).orElseThrow(() -> new NotFoundException("Estudiante no encontrado"));
        studentRepositorio.deleteById(id);
    }

    @Override
    public List<StudentOutputDTO> findAll() {
        List<Student> students=studentRepositorio.findAll();
        List<StudentOutputDTO> studentsOutputDTO= students.stream().map(s->new StudentOutputDTO(s)).collect(Collectors.toList());
        return studentsOutputDTO;
    }
}
