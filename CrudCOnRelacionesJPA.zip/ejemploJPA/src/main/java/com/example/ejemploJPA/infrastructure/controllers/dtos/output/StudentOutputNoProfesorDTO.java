package com.example.ejemploJPA.infrastructure.controllers.dtos.output;

import com.example.ejemploJPA.domain.entidades.asignatura.Asignatura;
import com.example.ejemploJPA.domain.entidades.student.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentOutputNoProfesorDTO {

    Integer id;
    Integer idPersona;
    Integer numHoursWeek;
    String branch;
    List<Asignatura> estudios;

    public StudentOutputNoProfesorDTO(Student student) {
        this.id=student.getId();
        this.idPersona =student.getPersona().getId();
        this.numHoursWeek = student.getNumHoursWeek();
        this.branch = student.getBranch();
        this.estudios=student.getEstudios();
    }
}
