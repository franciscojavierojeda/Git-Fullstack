package com.example.inyeccionDeDependencias;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class InyeccionDeDependenciasApplication {

  public static void main(String[] args) {
    SpringApplication.run(InyeccionDeDependenciasApplication.class, args);
  }

  @Bean
  public List<Ciudad> ciudades(){
    List<Ciudad> ciudades=new ArrayList<>();
    return ciudades;
  }

  @Bean
  @Qualifier("bean1")
  public Persona bean1(){
    Persona bean1=new Persona("Paco","Getafe",12);

    return bean1;
  }

  @Bean
  @Qualifier("bean2")
  public Persona bean2(){
    Persona bean2=new Persona("Manolo","Madrid",11);

    return bean2;

  }

  @Bean
  @Qualifier("bean3")
  public Persona bean3(){
    Persona bean3=new Persona("Juan","Lugo",16);

    return bean3;

  }
}
