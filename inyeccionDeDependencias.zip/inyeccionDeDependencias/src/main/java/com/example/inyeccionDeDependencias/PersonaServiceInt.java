package com.example.inyeccionDeDependencias;


public interface PersonaServiceInt {

    public void anadirPersona(Persona persona);
}
