package com.example.inyeccionDeDependencias;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class Controlador2 {

  @Autowired PersonaService personaService;

  @Autowired CiudadService ciudadService;

  @Autowired
  @Qualifier("bean1")
  Persona bean1;

  @Autowired
  @Qualifier("bean2")
  Persona bean2;

  @Autowired
  @Qualifier("bean3")
  Persona bean3;

  @GetMapping("/controlador2/getPersona")
  public String getDobleEdad() {
    Persona p = personaService.getPersona();
    return "Edad duplicada: " + p.getEdad() * 2;
  }

  @GetMapping("/controlador2/getCiudades")
  public String listarCiudades() {
    return ciudadService.getListaCiudades().toString();
  }

  @GetMapping("/controlador2/bean/{bean}")
  public String getBeanPersona(@PathVariable String bean) {
    if (bean.equals("bean1")) return bean1.toString();
    if (bean.equals("bean2")) return bean2.toString();
    if (bean.equals("bean3")) return bean3.toString();
    return "Persona no encontrada";
  }
}
