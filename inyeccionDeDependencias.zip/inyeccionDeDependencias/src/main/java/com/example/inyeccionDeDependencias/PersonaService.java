package com.example.inyeccionDeDependencias;

import org.springframework.stereotype.Service;

@Service
public class PersonaService implements PersonaServiceInt{

    private Persona p;
    @Override
    public void anadirPersona(Persona persona) {
        this.p=persona;
    }

    public Persona getPersona() {
        return p;
    }

    @Override
    public String toString() {
        return "PersonaService{" +
                "p=" + p +
                '}';
    }
}
