package com.example.inyeccionDeDependencias;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CiudadServiceImpl implements CiudadService {

    @Autowired
    List<Ciudad> listaCiudades;

    public void anadirCiudad(Ciudad ciudad){
        listaCiudades.add(ciudad);
    }

    public List<Ciudad> getListaCiudades() {
        return listaCiudades;
    }
}
