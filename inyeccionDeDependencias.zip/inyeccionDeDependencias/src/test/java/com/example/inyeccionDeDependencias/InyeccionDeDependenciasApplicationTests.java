package com.example.inyeccionDeDependencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InyeccionDeDependenciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
